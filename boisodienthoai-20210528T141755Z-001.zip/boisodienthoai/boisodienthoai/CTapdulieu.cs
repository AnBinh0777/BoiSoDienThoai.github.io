﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace boisodienthoai
{
    class CTapdulieu
    {
        string[,] noidung;



        public CTapdulieu() { 
        noidung= new string[80,2];
        }
        public CTapdulieu(string taptin)
        {
            noidung = new string[80, 2];
            FileStream file = new FileStream(taptin, FileMode.OpenOrCreate, FileAccess.Read);

            // Create a new stream to read from a file
            StreamReader sr = new StreamReader(file);
            string s;
            string[] a;
            // Read contents of file into a string
            while ((s = sr.ReadLine()) != null)
            {
           
                a = s.Split(';');
               noidung[int.Parse(a[0])+1,0]=a[1];
               noidung[int.Parse( a[0])+1,1]=a[2];
           }

            // Close StreamReader
            sr.Close();

            // Close file
            file.Close();



        }
        public string caubinh(int n) {
            return noidung[n, 0];
        
        }
        public string hungcat(int n) {
            return noidung[n, 1];
        
        }
        public string inxemthu(){
            string s="";
            for (int i = 0; i < 80;i++ )
            {
                s = s + "\n " + noidung[i, 0] + "/  /" + noidung[i, 1];


            }

                return s;
        
        }
    }
}
